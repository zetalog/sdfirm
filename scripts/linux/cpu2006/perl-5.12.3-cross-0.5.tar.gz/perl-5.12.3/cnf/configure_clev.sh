#!/bin/sh

# Clean the environment
cleanonly=1
. $base/configure_genc.sh
unset cleanonly
